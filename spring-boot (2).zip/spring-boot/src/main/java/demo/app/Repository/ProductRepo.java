package demo.app.Repository;

import demo.app.Model.Entity.ProductEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductRepo extends CrudRepository<ProductEntity, Long> {
    

    Optional<ProductEntity> findByProductId(String productId);
}
