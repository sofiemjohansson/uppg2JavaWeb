package demo.app.Service;

import demo.app.Model.Request.ProductRequestModel;
import demo.app.SharedDto.ProductDto;

public interface ProductService {

    ProductDto[] getAllProducts();
    ProductDto getProduct(ProductDto productDetailsIn);
    ProductDto createProduct(ProductDto productDetailsIn);
    ProductDto updateProduct(ProductDto productDetailsIn, ProductRequestModel proReqModel);
    void deleteProduct(ProductDto productDetails);    
}